# Ctruth_images > 2024-06-13 1:18am
https://universe.roboflow.com/ayush-vn1ho/ctruth_images

Provided by a Roboflow user
License: CC BY 4.0

